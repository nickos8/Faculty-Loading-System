<section class="space-y-4">

    {{-- Header card --}}
    <div class="rounded-2xl border border-white/40 bg-white/70 backdrop-blur shadow-sm">
        <div class="p-6 space-y-1">
            <h2 class="text-2xl font-semibold tracking-tight text-slate-900">
                {{ __('Email Address') }}
            </h2>
            <p class="text-sm text-slate-600">
                {{ __('Update the email address associated with your account.') }}
            </p>
        </div>
    </div>

    {{-- Form card --}}
    <div class="rounded-2xl border border-slate-200/70 bg-white shadow-sm overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-200 bg-slate-50/60">
            <div class="text-sm font-semibold text-slate-900">
                {{ __('Change Email') }}
            </div>
            <div class="text-xs text-slate-500">
                {{ __('A verification email may be sent after updating.') }}
            </div>
        </div>

        <form method="post"
              action="{{ route('profile.email.update') }}"
              class="p-6 space-y-5">
            @csrf
            @method('patch')

            {{-- Email --}}
            <div class="space-y-1">
                <x-input-label
                    for="email"
                    :value="__('Email')"
                    class="text-xs font-semibold text-slate-700"
                />
                <x-text-input
                    id="email"
                    name="email"
                    type="email"
                    autocomplete="email"
                    required
                    :value="old('email', $user->email)"
                    class="mt-1 block w-full rounded-xl border-slate-300 shadow-sm"
                />
                <x-input-error
                    :messages="$errors->get('email')"
                    class="mt-1 text-xs"
                />
            </div>

            {{-- Actions --}}
            <div class="flex items-center gap-4 pt-2">
                <x-primary-button class="rounded-xl">
                    {{ __('Save Email') }}
                </x-primary-button>

                @if (session('status') === 'email-updated')
                    <p
                        x-data="{ show: true }"
                        x-show="show"
                        x-transition
                        x-init="setTimeout(() => show = false, 2000)"
                        class="text-sm text-emerald-600"
                    >
                        {{ __('Email updated.') }}
                    </p>
                @endif
            </div>
        </form>
    </div>

</section>
