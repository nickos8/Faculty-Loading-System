<section class="space-y-4">

    {{-- Header card --}}
    <div class="rounded-2xl border border-white/40 bg-white/70 backdrop-blur shadow-sm">
        <div class="p-6 space-y-1">
            <h2 class="text-2xl font-semibold tracking-tight text-slate-900">
                {{ __('Update Password') }}
            </h2>
            <p class="text-sm text-slate-600">
                {{ __('Ensure your account is using a long, random password to stay secure.') }}
            </p>
        </div>
    </div>

    {{-- Form card --}}
    <div class="rounded-2xl border border-slate-200/70 bg-white shadow-sm overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-200 bg-slate-50/60">
            <div class="text-sm font-semibold text-slate-900">
                {{ __('Change Password') }}
            </div>
            <div class="text-xs text-slate-500">
                {{ __('All fields are required.') }}
            </div>
        </div>

        <form method="post"
              action="{{ route('password.update') }}"
              class="p-6 space-y-5">
            @csrf
            @method('put')

            {{-- Current password --}}
            <div class="space-y-1">
                <x-input-label
                    for="update_password_current_password"
                    :value="__('Current Password')"
                    class="text-xs font-semibold text-slate-700"
                />
                <x-text-input
                    id="update_password_current_password"
                    name="current_password"
                    type="password"
                    autocomplete="current-password"
                    class="mt-1 block w-full rounded-xl border-slate-300 shadow-sm"
                />
                <x-input-error
                    :messages="$errors->updatePassword->get('current_password')"
                    class="mt-1 text-xs"
                />
            </div>

            {{-- New password --}}
            <div class="space-y-1">
                <x-input-label
                    for="update_password_password"
                    :value="__('New Password')"
                    class="text-xs font-semibold text-slate-700"
                />
                <x-text-input
                    id="update_password_password"
                    name="password"
                    type="password"
                    autocomplete="new-password"
                    class="mt-1 block w-full rounded-xl border-slate-300 shadow-sm"
                />
                <x-input-error
                    :messages="$errors->updatePassword->get('password')"
                    class="mt-1 text-xs"
                />
            </div>

            {{-- Confirm password --}}
            <div class="space-y-1">
                <x-input-label
                    for="update_password_password_confirmation"
                    :value="__('Confirm Password')"
                    class="text-xs font-semibold text-slate-700"
                />
                <x-text-input
                    id="update_password_password_confirmation"
                    name="password_confirmation"
                    type="password"
                    autocomplete="new-password"
                    class="mt-1 block w-full rounded-xl border-slate-300 shadow-sm"
                />
                <x-input-error
                    :messages="$errors->updatePassword->get('password_confirmation')"
                    class="mt-1 text-xs"
                />
            </div>

            {{-- Actions --}}
            <div class="flex items-center gap-4 pt-2">
                <x-primary-button class="rounded-xl">
                    {{ __('Save Changes') }}
                </x-primary-button>

                @if (session('status') === 'password-updated')
                    <p
                        x-data="{ show: true }"
                        x-show="show"
                        x-transition
                        x-init="setTimeout(() => show = false, 2000)"
                        class="text-sm text-emerald-600"
                    >
                        {{ __('Password updated.') }}
                    </p>
                @endif
            </div>
        </form>
    </div>

</section>
