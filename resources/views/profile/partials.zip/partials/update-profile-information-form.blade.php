<section class="space-y-4">

    {{-- Header card --}}
    <div class="rounded-2xl border border-white/40 bg-white/70 backdrop-blur shadow-sm">
        <div class="p-6 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div class="space-y-1">
                <h2 class="text-2xl font-semibold tracking-tight text-slate-900">
                    {{ __('Profile Information') }}
                </h2>
                <p class="text-sm text-slate-600">
                    {{ __("View your account's profile details.") }}
                </p>

                {{-- Verification pill --}}
                @if ($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail)
                    <div class="mt-3 flex flex-wrap gap-2 text-xs">
                        @if ($user->hasVerifiedEmail())
                            <span class="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-emerald-800">
                                <span class="h-2 w-2 rounded-full bg-emerald-500"></span>
                                {{ __('Email Verified') }}
                            </span>
                        @else
                            <span class="inline-flex items-center gap-2 rounded-full border border-rose-200 bg-rose-50 px-3 py-1 text-rose-800">
                                <span class="h-2 w-2 rounded-full bg-rose-500"></span>
                                {{ __('Email Not Verified') }}
                            </span>
                        @endif
                    </div>
                @endif
            </div>
        </div>
    </div>

    {{-- Body card --}}
    <div class="rounded-2xl border border-slate-200/70 bg-white shadow-sm overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-200 bg-slate-50/60">
            <div class="text-sm font-semibold text-slate-900">{{ __('Account Details') }}</div>
            <div class="text-xs text-slate-500">{{ __('These fields are read-only.') }}</div>
        </div>

        <div class="p-6 space-y-5">

            {{-- School ID --}}
            <div class="space-y-1">
                <x-input-label for="school_id" :value="__('School ID')" class="text-xs font-semibold text-slate-700" />
                <x-text-input
                    id="school_id"
                    type="text"
                    class="mt-1 block w-full rounded-xl border-slate-300 bg-slate-100 text-slate-900 shadow-sm"
                    :value="$user->school_id"
                    disabled
                />
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                {{-- First Name --}}
                <div class="space-y-1">
                    <x-input-label for="first_name" :value="__('First Name')" class="text-xs font-semibold text-slate-700" />
                    <x-text-input
                        id="first_name"
                        type="text"
                        class="mt-1 block w-full rounded-xl border-slate-300 bg-slate-100 text-slate-900 shadow-sm"
                        :value="$user->first_name"
                        disabled
                    />
                </div>

                {{-- Last Name --}}
                <div class="space-y-1">
                    <x-input-label for="last_name" :value="__('Last Name')" class="text-xs font-semibold text-slate-700" />
                    <x-text-input
                        id="last_name"
                        type="text"
                        class="mt-1 block w-full rounded-xl border-slate-300 bg-slate-100 text-slate-900 shadow-sm"
                        :value="$user->last_name"
                        disabled
                    />
                </div>
            </div>

            {{-- Email --}}
            <div class="space-y-1">
                <x-input-label for="email" :value="__('Email')" class="text-xs font-semibold text-slate-700" />
                <x-text-input
                    id="email"
                    type="email"
                    class="mt-1 block w-full rounded-xl border-slate-300 bg-slate-100 text-slate-900 shadow-sm"
                    :value="$user->email"
                    disabled
                />
            </div>

        </div>
    </div>

</section>
