@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto p-6">

    {{-- Header --}}
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-bice-blue">Choose a Section</h1>

        <div class="mt-4">
            <a href="{{ url()->previous() }}"
               class="text-sm text-bice-blue hover:underline flex items-center gap-1">
                ← Back
            </a>
        </div>

        @if($program)
            <p class="text-sm text-slate-600 mt-2">
                Program:
                <span class="font-semibold text-bice-blue">
                    {{ $program->program_name }}
                </span>
            </p>
        @endif
    </div>


    {{-- Table --}}
    <div class="overflow-x-auto rounded-lg border border-bice-blue/30 shadow">
        <table class="min-w-full text-sm">
            <thead class="bg-indigo-dye text-white">
                <tr>
                    <th class="px-5 py-3 text-left font-medium">Section</th>
                    <th class="px-5 py-3 text-left font-medium">Curriculum</th>
                    <th class="px-5 py-3 text-left font-medium"></th>
                    <th class="px-5 py-3 text-left font-medium"></th>
                    <th class="px-5 py-3 text-left font-medium"></th>
                </tr>
            </thead>

            <tbody class="divide-y divide-pale-azure/40">
                @forelse($sections as $row)
                    <tr class="hover:bg-non-photo-blue/30 transition">
                        <td class="px-5 py-4 font-medium text-bice-blue">
                            {{ $row->section_name }}
                        </td>

                        <td class="px-5 py-4 text-slate-700">
                            {{ $row->curriculum_code }}
                        </td>

                        <td class="px-5 py-4 text-slate-700">
                            Year {{ $row->year_level }}
                        </td>

                        <td class="px-5 py-4 text-slate-700">
                            Term {{ $row->term_no }}
                        </td>

                        <td class="px-5 py-4 text-right">
                            <a href="{{ route('admin.schedules.sections.show', $row->id) }}"
                               class="inline-flex items-center rounded-lg bg-picton-blue px-3 py-1 text-white shadow hover:bg-bice-blue transition">
                                Manage Schedule
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="px-5 py-10 text-center text-slate-500">
                            No active sections found for your program.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

</div>
@endsection
