@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold mb-4">Edit schedule</h1>

    <div class="mb-4">
        <a href="{{ route('admin.schedules.sections.show', $sectionId) }}"
           class="text-sm text-gray-600 hover:text-gray-800">
            ← Back to section schedule
        </a>
    </div>

    @if (session('status'))
        <div class="mb-4 rounded bg-green-100 text-green-800 px-4 py-2">
            {{ session('status') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="mb-4 rounded bg-red-100 text-red-800 px-4 py-2">
            <ul class="list-disc list-inside text-sm">
                @foreach ($errors->all() as $e)
                    <li>{{ $e }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST"
          action="{{ route('admin.schedules.sections.offerings.update', [$sectionId, $offering->id]) }}"
          class="grid gap-4 md:grid-cols-3 bg-white rounded border px-4 py-4">
        @csrf
        @method('PUT')

        <input type="hidden"
       name="curriculum_term_subject_id"
       id="cts_id"
       value="{{ $offering->curriculum_term_subject_id }}">


        {{-- Start / End date --}}
        <div>
            <label class="block text-sm font-medium mb-1">Start date</label>
            <input type="date"
                   name="start_date"
                   value="{{ old('start_date', $offering->start_date) }}"
                   class="w-full border rounded p-2"
                   required>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">End date</label>
            <input type="date"
                   name="end_date"
                   value="{{ old('end_date', $offering->end_date) }}"
                   class="w-full border rounded p-2"
                   required>
        </div>

        {{-- Day of week --}}
        <div>
            <label class="block text-sm font-medium mb-1">Day of week</label>
            @php
                $dayOptions = [1=>'Mon',2=>'Tue',3=>'Wed',4=>'Thu',5=>'Fri',6=>'Sat',7=>'Sun'];
                $currentDay = old('day_of_week', optional($meeting)->day_of_week);
            @endphp
            <select name="day_of_week" class="w-full border rounded p-2" required>
                <option value="">Select day</option>
                @foreach($dayOptions as $val => $label)
                    <option value="{{ $val }}" @selected($currentDay == $val)>
                        {{ $label }}
                    </option>
                @endforeach
            </select>
        </div>

        {{-- Time start / end --}}
        <div>
            <label class="block text-sm font-medium mb-1">Time in</label>
            <input type="time"
                   name="time_start"
                   value="{{ old('time_start', optional($meeting)->time_start ? substr($meeting->time_start, 0, 5) : null) }}"
                   class="w-full border rounded p-2"
                   required>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Time out</label>
            <input type="time"
                   name="time_end"
                   value="{{ old('time_end', optional($meeting)->time_end ? substr($meeting->time_end, 0, 5) : null) }}"
                   class="w-full border rounded p-2 cursor-not-allowed"
                    readonly
                   required>
        </div>

        {{-- Teacher --}}
        <div>
            <label class="block text-sm font-medium mb-1">Teacher</label>
            @php
    $currentTeacherId = old('teacher_id', optional($meeting)->teacher_id);
@endphp

<div>
    <label class="block text-sm font-medium mb-1"></label>
    <select name="teacher_id"
            id="teacher_id"
            class="w-full border rounded p-2"
            required>
        <option value="">Loading available teachers…</option>
    </select>
    <p id="teacher_notice" class="text-xs text-red-600 mt-1 hidden"></p>
</div>




        {{-- Room --}}
        <div>
            <label class="block text-sm font-medium mb-1">Room</label>
            @php
    $currentRoomId = old('room_id', optional($meeting)->room_id);
@endphp

<div>
    <label class="block text-sm font-medium mb-1"></label>
    <select name="room_id"
            id="room_id"
            class="w-full border rounded p-2"
            required>
        <option value="">Loading available rooms…</option>
    </select>
    <p id="room_notice" class="text-xs text-red-600 mt-1 hidden"></p>
</div>


        {{-- Submit --}}
        <div class="md:col-span-3 mt-2">
            <button type="submit"
                    class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded hover:bg-blue-700">
                Save changes
            </button>
        </div>
    </form>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // Units passed from the controller (1 unit = 60 minutes)
    const units = {{ (int) ($effectiveUnits ?? 0) }};
    if (!units) return; // nothing to do if we don't know the units

    const startInput = document.querySelector('input[name="time_start"]');
    const endInput   = document.querySelector('input[name="time_end"]');

    if (!startInput || !endInput) return;

    let autoEnd = true; // once the user edits End manually, we stop auto-calculating

    function hhmmToMinutes(hhmm) {
        const [h, m] = (hhmm || '').split(':').map(v => parseInt(v, 10) || 0);
        return h * 60 + m;
    }

    function minutesToHHMM(mins) {
        const total = Math.max(0, Math.min(mins, (24 * 60) - 1)); // clamp 00:00..23:59
        const h = String(Math.floor(total / 60)).padStart(2, '0');
        const m = String(total % 60).padStart(2, '0');
        return `${h}:${m}`;
    }

    function recomputeEnd() {
        if (!autoEnd) return;
        if (!startInput.value) return;

        const startMins = hhmmToMinutes(startInput.value);
        const endMins   = startMins + (units * 60); // 1 unit = 60 minutes
        endInput.value  = minutesToHHMM(endMins);
    }

    // When Time in changes -> recompute Time out
    startInput.addEventListener('change', recomputeEnd);

    // When user changes Time out manually -> stop auto updates
    endInput.addEventListener('change', function () {
        autoEnd = false;
    });

    // Initial auto-fill when page loads (helpful after validation errors)
    recomputeEnd();
});


//room and teacher options loading
document.addEventListener('DOMContentLoaded', function () {
    const sectionId       = {{ (int) $sectionId }};
    const ctsId           = {{ (int) $offering->curriculum_term_subject_id }};
    const ignoreMeetingId = {{ (int) $meeting->id }};
    const currentTeacherId = {{ (int) ($currentTeacherId ?? 0) }};
    const currentRoomId    = {{ (int) ($currentRoomId ?? 0) }};

    const startDate = document.querySelector('input[name="start_date"]');
    const endDate   = document.querySelector('input[name="end_date"]');
    const daySelect = document.querySelector('select[name="day_of_week"]');
    const tStart    = document.querySelector('input[name="time_start"]');
    const tEnd      = document.querySelector('input[name="time_end"]');

    const teacherSelect = document.getElementById('teacher_id');
    const roomSelect    = document.getElementById('room_id');
    const teacherNotice = document.getElementById('teacher_notice');
    const roomNotice    = document.getElementById('room_notice');

    const teachersUrlBase = @json(route('admin.schedules.sections.available-teachers', $sectionId));
    const roomsUrlBase    = @json(route('admin.schedules.sections.available-rooms', $sectionId));

    function haveAllInputs() {
        return ctsId &&
               startDate.value &&
               endDate.value &&
               daySelect.value &&
               tStart.value &&
               tEnd.value;
    }

    function buildUrl(base) {
        const url = new URL(base);
        url.searchParams.set('curriculum_term_subject_id', ctsId);
        url.searchParams.set('start_date', startDate.value);
        url.searchParams.set('end_date', endDate.value);
        url.searchParams.set('day_of_week', daySelect.value);
        url.searchParams.set('time_start', tStart.value);
        url.searchParams.set('time_end', tEnd.value);
        url.searchParams.set('ignore_meeting_id', ignoreMeetingId); // ← key line
        return url.toString();
    }

    async function refreshTeachers() {
        if (!haveAllInputs()) {
            teacherSelect.innerHTML = '<option value="">Fill date, day and time first</option>';
            teacherNotice.classList.add('hidden');
            return;
        }

        teacherSelect.innerHTML = '<option value="">Loading…</option>';
        teacherNotice.classList.add('hidden');

        try {
            const res = await fetch(buildUrl(teachersUrlBase), {
                headers: { 'Accept': 'application/json' }
            });
            const list = res.ok ? await res.json() : [];

            if (!list.length) {
                teacherSelect.innerHTML = '<option value="">No available teachers</option>';
                teacherNotice.textContent = 'No teacher is available for this schedule.';
                teacherNotice.classList.remove('hidden');
                return;
            }

            let html = '<option value="">-- Choose teacher --</option>';
            let canKeepCurrent = false;

            for (const t of list) {
                const selected = (t.id === currentTeacherId) ? ' selected' : '';
                if (selected) canKeepCurrent = true;
                html += `<option value="${t.id}"${selected}>${t.name}</option>`;
            }

            teacherSelect.innerHTML = html;

            if (!canKeepCurrent && currentTeacherId) {
                teacherNotice.textContent =
                    'The previously assigned teacher is not available in this window. Please choose another.';
                teacherNotice.classList.remove('hidden');
            } else {
                teacherNotice.classList.add('hidden');
            }

        } catch (e) {
            teacherSelect.innerHTML = '<option value="">Error loading teachers</option>';
        }
    }

    async function refreshRooms() {
        if (!haveAllInputs()) {
            roomSelect.innerHTML = '<option value="">Fill date, day and time first</option>';
            roomNotice.classList.add('hidden');
            return;
        }

        roomSelect.innerHTML = '<option value="">Loading…</option>';
        roomNotice.classList.add('hidden');

        try {
            const res = await fetch(buildUrl(roomsUrlBase), {
                headers: { 'Accept': 'application/json' }
            });
            const list = res.ok ? await res.json() : [];

            if (!list.length) {
                roomSelect.innerHTML = '<option value="">No available rooms</option>';
                roomNotice.textContent =
                    'The previously assigned room is not available in this window. Please choose another.';
                roomNotice.classList.remove('hidden');
                return;
            }

            let html = '<option value="">-- Choose room --</option>';
            let canKeepCurrent = false;

            for (const r of list) {
                const selected = (r.id === currentRoomId) ? ' selected' : '';
                if (selected) canKeepCurrent = true;
                html += `<option value="${r.id}"${selected}>${r.name}</option>`;
            }

            roomSelect.innerHTML = html;

            if (!canKeepCurrent && currentRoomId) {
                roomNotice.textContent =
                    'The previously assigned room is not available in this window. Please choose another.';
                roomNotice.classList.remove('hidden');
            } else {
                roomNotice.classList.add('hidden');
            }

        } catch (e) {
            roomSelect.innerHTML = '<option value="">Error loading rooms</option>';
        }
    }

    function refreshAll() {
        refreshTeachers();
        refreshRooms();
    }

    // Trigger refresh when schedule parameters change
    [startDate, endDate, daySelect, tStart, tEnd].forEach(el => {
        if (el) el.addEventListener('change', refreshAll);
    });

    // Initial population when edit page loads
    refreshAll();
});
</script>
@endsection


