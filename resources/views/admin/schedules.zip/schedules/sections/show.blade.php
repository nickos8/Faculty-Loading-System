@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto px-6 py-6 space-y-6">

    {{-- Flash messages --}}
    @if(session('status'))
        <div class="mb-4 rounded-lg bg-non-photo-blue text-indigo-dye px-4 py-3 shadow-sm">
            {{ session('status') }}
        </div>
    @endif

    @if($errors->any())
        <div class="mb-4 rounded-lg bg-pale-azure text-indigo-dye px-4 py-3 shadow-sm border border-bice-blue/40">
            <ul class="list-disc list-inside text-sm">
                @foreach($errors->all() as $e)
                    <li>{{ $e }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    {{-- ADD SCHEDULE CARD --}}
    <div class="rounded-lg border border-bice-blue/30 bg-white p-5 shadow"
         x-data="scheduleForm()"
         x-init="init()"
         x-effect="debouncedRefresh(ctsId,startDate,endDate,dow,tStart,tEnd)">

        {{-- Card header --}}
        <div class="mb-4 flex flex-col gap-1 md:flex-row md:items-center md:justify-between">
    <div class="text-center md:text-left">
        <h2 class="text-xl font-semibold text-bice-blue"><span class="ml-1 font-semibold">{{ $section->name ?? '—' }}</span></h2>
        <p class="text-xs text-slate-500">
            Choose a subject, set dates and times, then assign an available teacher and room.
        </p>
    </div>
</div>


        <form method="POST"
      action="{{ route('admin.schedules.sections.offerings.store', $section->id) }}"
      class="  space-y-8 p-6 md:p-8 bg-white rounded-lg border border-gray-200 shadow">

    @csrf


    {{-- ========================= --}}
    {{-- SECTION: SUBJECT & DATES --}}
    {{-- ========================= --}}
    <div class="space-y-4">


        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

            {{-- Subject --}}
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    Subject <span class="text-red-500"></span>
                </label>

                <select
                    name="curriculum_term_subject_id"
                    x-model="ctsId"
                    @change="onStartOrSubjectChanged()"
                    class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-picton-blue focus:border-picton-blue"
                    required>
                    <option value="">Select subject…</option>
                    @foreach($requiredSubjects as $s)
                        <option
                            value="{{ $s->cts_id }}"
                            data-units="{{ $s->units }}"
                            data-type="{{ $s->type ?? '' }}"
                            data-remaining="{{ $s->remaining_minutes ?? ($s->units * 60) }}"
                            data-offer-start="{{ $s->offering_start_date ?? '' }}"
                            data-offer-end="{{ $s->offering_end_date ?? '' }}"
                        >
                            {{ $s->code }} {{ $s->name }} ({{ $s->units }} Units)
                        </option>
                    @endforeach
                </select>

                <p class="text-xs text-gray-500 mt-1">
                    Auto-fills schedule length based on subject units.
                </p>
            </div>

            {{-- Start date --}}
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Start date</label>

                <input type="date"
                       name="start_date"
                       x-model="startDate"
                       :readonly="hasExistingOffering"
                       class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-picton-blue focus:border-picton-blue"
                       required>
            </div>

            {{-- End date --}}
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">End date</label>

                <input type="date"
                       name="end_date"
                       x-model="endDate"
                       :readonly="hasExistingOffering"
                       class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-picton-blue focus:border-picton-blue"
                       required>
            </div>

        </div>
    </div>


    {{-- =========================== --}}
    {{-- SECTION: MEETING DETAILS    --}}
    {{-- =========================== --}}
    <div class="space-y-4">


        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">

            {{-- Day --}}
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Day of week</label>

                <select
                    name="day_of_week"
                    x-model.number="dow"
                    class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-picton-blue focus:border-picton-blue"
                    required>
                    @foreach([0=>'Select Day', 1=>'Mon',2=>'Tue',3=>'Wed',4=>'Thu',5=>'Fri',6=>'Sat',7=>'Sun'] as $d=>$n)
                        <option value="{{ $d }}">{{ $n }}</option>
                    @endforeach
                </select>
            </div>

            {{-- Time in --}}
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Time in</label>

                <input type="time"
                       name="time_start"
                       x-model="tStart"
                       @change="onStartOrSubjectChanged()"
                       class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-picton-blue focus:border-picton-blue"
                       required>
            </div>

            {{-- Time out --}}
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Time out</label>

                <input type="time"
                       name="time_end"
                       x-model="tEnd"
                       @change="autoEnd=false; maybeRefreshOptions()"
                       readonly
                       class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm bg-gray-100 cursor-not-allowed focus:ring-picton-blue focus:border-picton-blue"
                       required>

                <p class="text-xs text-gray-500 mt-1">
                    Auto-calculated from subject units.
                </p>
            </div>

        </div>
    </div>



    {{-- SECTION: ASSIGNMENTS        --}}

    <div class="space-y-4">


        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">

            {{-- Teacher --}}
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1">Teacher</label>

                <select name="teacher_id"
                        class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm disabled:bg-gray-100 focus:ring-picton-blue focus:border-picton-blue"
                        :disabled="!ready || loadingTeachers"
                        x-html="teacherOptionsHtml()"
                        required>
                </select>

                <p class="text-xs text-gray-500 mt-1" x-show="loadingTeachers">
                    Loading teachers…
                </p>
            </div>

            {{-- Room --}}
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1">Room</label>

                <select name="room_id"
                        class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm disabled:bg-gray-100 focus:ring-picton-blue focus:border-picton-blue"
                        :disabled="!ready || loadingRooms"
                        x-html="roomOptionsHtml()"
                        required>
                </select>

                <p class="text-xs text-gray-500 mt-1" x-show="loadingRooms">
                    Loading rooms…
                </p>
            </div>

        </div>
    </div>


    {{-- SUBMIT BUTTON --}}
    <div class="flex justify-end pt-4">
        <button type="submit"
                class="rounded-lg bg-picton-blue px-5 py-2 text-sm font-medium text-white shadow hover:bg-bice-blue transition disabled:opacity-60"
                :disabled="!haveAll()">
            Save schedule
        </button>
    </div>

</form>


    </div>

    {{-- EXISTING SCHEDULES TABLE --}}
<div class="rounded-lg border border-bice-blue/30 bg-white shadow">

    {{-- Header bar --}}
    <div class="px-4 md:px-5 py-3 border-b border-pale-azure/60 flex items-center justify-between">
        <h3 class="text-sm font-semibold text-bice-blue">Existing schedules</h3>
        <span class="text-xs text-slate-500">
            {{ $offerings->count() }} total
        </span>
    </div>

    {{-- 🔹 Responsive scroll wrapper --}}
    <div class="overflow-x-auto">
        <table class="min-w-[900px] w-full text-xs md:text-sm">
            <thead class="bg-indigo-dye text-white">
                <tr>
                    <th class="px-3 md:px-5 py-3 text-left font-medium">Dates</th>
                    <th class="px-3 md:px-5 py-3 text-left font-medium">Subject</th>
                    <th class="px-3 md:px-5 py-3 text-left font-medium">Day</th>
                    <th class="px-3 md:px-5 py-3 text-left font-medium">Time</th>
                    <th class="px-3 md:px-5 py-3 text-left font-medium">Teacher</th>
                    <th class="px-3 md:px-5 py-3 text-left font-medium">Room</th>
                    <th class="px-3 md:px-5 py-3 text-left font-medium"></th>
                </tr>
            </thead>

            <tbody class="divide-y divide-pale-azure/40">
            @forelse($offerings as $off)
                @php
                    $subj = \DB::table('curriculum_term_subjects as cts')
                        ->join('subjects as s','s.id','=','cts.subject_id')
                        ->where('cts.id', $off->curriculum_term_subject_id)
                        ->select('s.code','s.name')->first();

                    $days = [1=>'Monday',2=>'Tuesday',3=>'Wednesday',4=>'Thursday',5=>'Friday',6=>'Saturday',7=>'Sunday'];
                @endphp

                @foreach($off->meetings as $m)
                    <tr class="hover:bg-non-photo-blue/30 transition">

                        {{-- DATES (only on first row) --}}
                        <td class="px-3 md:px-5 py-3 text-slate-700 align-top">
                            @if($loop->first)
                                {{ $off->start_date }} → {{ $off->end_date }}
                            @endif
                        </td>

                        {{-- SUBJECT (only on first row for this offering) --}}
                        <td class="px-3 md:px-5 py-3 font-medium text-bice-blue align-top">
                            @if($loop->first)
                                {{ $subj?->code }} | {{ $subj?->name }}
                            @endif
                        </td>



                        {{-- DAY --}}
                        <td class="px-3 md:px-5 py-3 text-slate-700 whitespace-nowrap">
                            {{ $days[$m->day_of_week] ?? $m->day_of_week }}
                        </td>

                        {{-- TIME --}}
                        <td class="px-3 md:px-5 py-3 text-slate-700 whitespace-nowrap">
                            {{ Str::substr($m->time_start,0,5) }}–{{ Str::substr($m->time_end,0,5) }}
                        </td>

                        {{-- TEACHER --}}
                        <td class="px-3 md:px-5 py-3 text-slate-700">
                            <span class="block max-w-[8rem] md:max-w-none truncate">
                                {{ optional($m->teacher)->first_name }}
                                {{ optional($m->teacher)->last_name }}
                            </span>
                        </td>

                        {{-- ROOM --}}
                        <td class="px-3 md:px-5 py-3 text-slate-700 whitespace-nowrap">
                            {{ optional($m->room)->name ?? '—' }}
                        </td>

                        {{-- ACTION (only on first row) --}}
                        <td class="px-3 md:px-5 py-3 text-center align-top">
                            @if($loop->first)
                                <a href="{{ route('admin.schedules.sections.offerings.edit', [$section->id, $off->id]) }}"
                                   class="inline-flex items-center rounded-lg bg-picton-blue px-3 py-1 text-[11px] md:text-xs font-medium text-white shadow hover:bg-bice-blue transition">
                                    Edit
                                </a>
                            @endif
                        </td>

                    </tr>
                @endforeach

            @empty
                <tr>
                    <td colspan="7" class="px-5 py-10 text-center text-gray-500">
                        No schedules yet.
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>

</div>




<script>
function scheduleForm() {
  return {
    // ----- original state -----
    ctsId:'', startDate:'', endDate:'', dow:'', tStart:'', tEnd:'',
    ready:false, loadingTeachers:false, loadingRooms:false,
    teachers:[], rooms:[], to:null,

     // Derived from selected subject
    subjectUnits: 0,
    subjectType: '',
    subjectRemaining: 0, // minutes
    offerStart: '',      // from data-offer-start
    offerEnd: '',        // from data-offer-end
    autoEnd: true,       // stop auto end-time when user edits End

    // Dependent dropdowns
    ready:false, loadingTeachers:false, loadingRooms:false,
    teachers:[], rooms:[],

    init(){ this.maybeRefreshOptions(); },

    haveAll(){ return this.ctsId && this.startDate && this.endDate && this.dow && this.tStart && this.tEnd; },

   onStartOrSubjectChanged() {
  this.updateSubjectMeta(); // reads units/remaining/type + offerStart/offerEnd

  // Decide if this subject has existing offering dates
  this.hasExistingOffering = !!(this.offerStart || this.offerEnd);

  // If offering dates exist, auto-fill and lock the date fields
  if (this.hasExistingOffering) {
    if (this.offerStart) this.startDate = this.offerStart;
    if (this.offerEnd)   this.endDate   = this.offerEnd;
  }

  if (this.autoEnd) this.autofillEndFromRemaining();
  this.maybeRefreshOptions();
},


    updateSubjectMeta() {
      const sel = document.querySelector('select[name="curriculum_term_subject_id"]');
      const opt = sel?.selectedOptions?.[0];
      if (!opt) {
        this.subjectUnits = 0; this.subjectType = ''; this.subjectRemaining = 0;
        this.offerStart=''; this.offerEnd='';
        return;
      }
      this.subjectUnits     = Number(opt.dataset.units || 0);
      this.subjectType      = (opt.dataset.type || '').toLowerCase();
      this.subjectRemaining = Number(opt.dataset.remaining || (this.subjectUnits * 60) || 0);
      this.offerStart       = (opt.dataset.offerStart || '');
      this.offerEnd         = (opt.dataset.offerEnd || '');
    },


    // ----- new: auto-end control -----
    autoEnd: true, // once user manually edits End, we stop auto-filling

    // ===== lifecycle =====
    init(){
      // attach listeners without changing your HTML
      const subjectSel = document.querySelector('select[name="curriculum_term_subject_id"]');
      const startInput = document.querySelector('input[name="time_start"]');
      const endInput   = document.querySelector('input[name="time_end"]');

      if (subjectSel && startInput && endInput) {
        // subject or start changes -> recompute end + debounce fetch
        subjectSel.addEventListener('change', () => {
          this.syncFromInputs();
          this.recomputeEnd();
          this.debouncedRefresh();
        });
        startInput.addEventListener('change', () => {
          this.syncFromInputs();
          this.recomputeEnd();
          this.debouncedRefresh();
        });
        // end changes by user -> stop auto, sync model, debounce fetch
        endInput.addEventListener('change', () => {
          this.autoEnd = false;
          this.tEnd = endInput.value;
          this.debouncedRefresh();
        });
      }

      // initial run (e.g., after validation error)
      this.syncFromInputs();
      this.recomputeEnd();
      this.maybeRefreshOptions();
    },

    // Keep Alpine state in sync with DOM inputs that vanilla listeners touched
    syncFromInputs(){
      const subjectSel = document.querySelector('select[name="curriculum_term_subject_id"]');
      const startInput = document.querySelector('input[name="time_start"]');
      const endInput   = document.querySelector('input[name="time_end"]');
      if (subjectSel) this.ctsId  = subjectSel.value;
      if (startInput) this.tStart = startInput.value;
      if (endInput)   this.tEnd   = endInput.value;
    },

    // ===== original: readiness + debounce =====
    haveAll(){ return this.ctsId && this.startDate && this.endDate && this.dow && this.tStart && this.tEnd; },
    debouncedRefresh(){ clearTimeout(this.to); this.to = setTimeout(()=>this.maybeRefreshOptions(), 250); },

    // ===== merged: auto end-time (1 unit = 60 min) =====
    recomputeEnd(){
      if (!this.autoEnd) return;

      const subjectSel = document.querySelector('select[name="curriculum_term_subject_id"]');
      const startInput = document.querySelector('input[name="time_start"]');
      const endInput   = document.querySelector('input[name="time_end"]');
      if (!subjectSel || !startInput || !endInput) return;

      const opt   = subjectSel.selectedOptions[0];
      let units   = this.parseUnitsFromOptionText(opt); // parse "(3u)" or "3 units" from label

      // Optional fallback: if you defined window.SUBJECT_UNITS = { cts_id: units }
      if ((!units || Number.isNaN(units)) && window.SUBJECT_UNITS) {
        const id = subjectSel.value;
        const v  = window.SUBJECT_UNITS[id];
        units = v != null ? parseInt(v,10) : null;
      }

      const start = startInput.value;
      if (!units || !start) return;

      const endMins = this.hhmmToMinutes(start) + (units * 60); // 1 unit = 60 min
      const newEnd  = this.minutesToHHMM(endMins);

      // update both DOM and Alpine to avoid desync
      endInput.value = newEnd;
      this.tEnd = newEnd;
    },

    parseUnitsFromOptionText(opt){
      if (!opt) return null;
      const txt = (opt.textContent || '').trim();
      // match "(3u)" or "3 units" (case-insensitive)
      const m = txt.match(/\((\d+)\s*u\)/i) || txt.match(/(\d+)\s*units?/i);
      return m ? parseInt(m[1], 10) : null;
    },
    hhmmToMinutes(hhmm){ const [h,m]=(hhmm||'').split(':').map(v=>parseInt(v,10)||0); return h*60+m; },
    minutesToHHMM(mins){
      const t = Math.max(0, Math.min(mins, (24*60)-1)); // clamp to 23:59
      const h = String(Math.floor(t/60)).padStart(2,'0');
      const m = String(t%60).padStart(2,'0');
      return `${h}:${m}`;
    },

    // ===== original: available teachers/rooms =====
    async maybeRefreshOptions(){
      this.ready = this.haveAll();
      if(!this.ready){ this.teachers=[]; this.rooms=[]; return; }
      await Promise.all([this.fetchTeachers(), this.fetchRooms()]);
    },

    async fetchTeachers(){
      this.loadingTeachers = true;
      try{
        const url = new URL(@json(route('admin.schedules.sections.available-teachers', $section->id)));
        url.searchParams.set('curriculum_term_subject_id', this.ctsId);
        url.searchParams.set('start_date', this.startDate);
        url.searchParams.set('end_date', this.endDate);
        url.searchParams.set('day_of_week', this.dow);
        url.searchParams.set('time_start', this.tStart);
        url.searchParams.set('time_end', this.tEnd);
        const res = await fetch(url.toString(), { headers:{ 'Accept':'application/json' }});
        this.teachers = res.ok ? await res.json() : [];
      } finally { this.loadingTeachers = false; }
    },

    async fetchRooms(){
      this.loadingRooms = true;
      try{
        const url = new URL(@json(route('admin.schedules.sections.available-rooms', $section->id)));
        url.searchParams.set('curriculum_term_subject_id', this.ctsId);
        url.searchParams.set('start_date', this.startDate);
        url.searchParams.set('end_date', this.endDate);
        url.searchParams.set('day_of_week', this.dow);
        url.searchParams.set('time_start', this.tStart);
        url.searchParams.set('time_end', this.tEnd);
        const res = await fetch(url.toString(), { headers:{ 'Accept':'application/json' }});
        this.rooms = res.ok ? await res.json() : [];
      } finally { this.loadingRooms = false; }
    },

    teacherOptionsHtml(){
      if(!this.ready) return '<option value="">fill fields above first</option>';
      if(this.loadingTeachers) return '<option value="">Loading…</option>';
      if(this.teachers.length===0) return '<option value="">No available teachers</option>';
      return ['<option value="">-- Choose teacher --</option>']
        .concat(this.teachers.map(t=>`<option value="${t.id}">${t.name}</option>`)).join('');
    },

    roomOptionsHtml(){
      if(!this.ready) return '<option value="">fill fields above first</option>';
      if(this.loadingRooms) return '<option value="">Loading…</option>';
      if(this.rooms.length===0) return '<option value="">No available rooms</option>';
      return ['<option value="">-- Choose room --</option>']
        .concat(this.rooms.map(r=>`<option value="${r.id}">${r.name}</option>`)).join('');
    },
  }
}
</script>



@endsection
