@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-6">

    @if(session('status'))
        <div class="mb-4 rounded bg-green-50 px-4 py-3 text-sm text-green-700">
            {{ session('status') }}
        </div>
    @endif

    @if($errors->any())
        <div class="mb-4 rounded bg-red-50 px-4 py-3 text-sm text-red-700">
            <ul class="list-disc pl-5 space-y-1">
                @foreach($errors->all() as $e)
                    <li>{{ $e }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="mb-6">
        <h1 class="text-2xl font-semibold"><span class="font-medium">{{ $section->name }}</span></h1>

            {{--
        <p class="text-sm text-gray-600 mt-1">
            Program: <span class="font-medium">{{ $section->program_name }}</span>
        </p>
        <p class="text-sm text-gray-600">
            Curriculum: <span class="font-medium">{{ $section->curriculum_code }}</span>
        </p>
        <p class="text-sm text-gray-600">
            Section:
            <span class="font-medium">{{ $section->name }}</span>
            (Year {{ $section->year_level }} • Term {{ $section->term_no }})
        </p>
        --}}

        <div class="mt-4">
            <a href="{{ route('sections.index') }}"
               class="text-sm text-gray-600 hover:text-gray-800">
                ← Back to sections
            </a>
        </div>
    </div>

    <form method="POST"
      action="{{ route('admin.schedules.sections.students.batch-update', $section->id) }}"
      onsubmit="return confirm('Are you sure you want to apply these changes to the selected students?');">
        @csrf

        <div class="bg-white rounded-lg shadow-sm overflow-hidden border">
            <table class="min-w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left">
                        <th class="px-5 py-3">
                            <input type="checkbox" id="check-all" class="h-4 w-4">
                        </th>
                        <th class="px-5 py-3 font-medium">Student Name</th>
                        <th class="px-5 py-3 font-medium">School ID</th>
                        <th class="px-5 py-3 font-medium">Email</th>
                        <th class="px-5 py-3 font-medium">Gender</th>
                        <th class="px-5 py-3 font-medium">Academic Status</th>
                        <th class="px-5 py-3 font-medium">Enrollment Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($students as $student)
                        <tr class="border-t hover:bg-gray-50">
                            <td class="px-5 py-3">
                                <input type="checkbox"
                                       name="academic_ids[]"
                                       value="{{ $student->academic_id }}"
                                       class="h-4 w-4 student-checkbox">
                            </td>
                            <td class="px-5 py-3">
                                {{ $student->last_name }}, {{ $student->first_name }}
                            </td>
                            <td class="px-5 py-3">
                                {{ $student->school_id }}
                            </td>
                            <td class="px-5 py-3">
                                {{ $student->email }}
                            </td>
                            <td class="px-5 py-3">
                                {{ $student->gender }}
                            </td>
                            <td class="px-5 py-3">
                                {{ ucfirst($student->academic_status) }}
                            </td>
                            <td class="px-5 py-3">
                                {{ ucfirst($student->enrollment_status) }}
                            </td>
                        </tr>
                    @empty
                        <tr class="border-t">
                            <td colspan="7" class="px-5 py-10 text-center text-gray-500">
                                No students found for this section.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>

            @if($students->count())
                <div class="border-t bg-gray-50 px-5 py-4 flex flex-wrap items-center gap-4">
                    <div>
                        <label for="target_section_id" class="block text-xs font-semibold text-gray-700">
                            New section (optional)
                        </label>
                        <select id="target_section_id"
                                name="target_section_id"
                                class="mt-1 block w-64 rounded-md border-gray-300 text-sm">
                            <option value="">Keep current section</option>
                            @foreach($candidateSections as $sec)
                                <option value="{{ $sec->id }}">
                                    {{ $sec->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label for="enrollment_status" class="block text-xs font-semibold text-gray-700">
                            New enrollment status (optional)
                        </label>
                        <select id="enrollment_status"
                                name="enrollment_status"
                                class="mt-1 block w-56 rounded-md border-gray-300 text-sm">
                            <option value="">Keep current status</option>
                            @foreach($enrollmentStatuses as $status)
                                <option value="{{ $status }}">{{ ucfirst($status) }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="ml-auto">
                        <button type="submit">
                            Apply changes to selected students
                        </button>
                    </div>
                </div>
            @endif
        </div>
    </form>
</div>

{{-- Simple "select all" --}}
@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    const checkAll = document.getElementById('check-all');
    if (!checkAll) return;

    checkAll.addEventListener('change', function (e) {
        const checked = e.target.checked;
        document.querySelectorAll('.student-checkbox').forEach(function (cb) {
            cb.checked = checked;
        });
    });
});
</script>
@endpush
@endsection
